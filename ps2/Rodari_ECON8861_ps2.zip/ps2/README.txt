----------------------------------------------------
-------------- Problem Set 2 ECON8861 --------------
----------------------------------------------------
-------------- Federico Rodari (2022) --------------


1) Setup (line 18-42)

Modify all directories to allow the code import the required modules.
Import packages if needed, but should be included in the local environment objects "Project.toml/Manifest.toml"

1) Section (line 89-306)

Follow line 93-98 to give the correct input in line 100. 
If a correct input is not given, an error message will appear suggesting to check the spelling.