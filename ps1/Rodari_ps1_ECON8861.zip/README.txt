
- In 01-ss_solution.jl change the working directory to include the utils file.
- Change parent directory (line 30, main.jl) to save correctly the figures (create the folder first, if needed)
